package Functionaltest;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test {
	public static void main(String[] args) throws IOException, InterruptedException {
		System.setProperty("webdriver.gecko.driver", "./software/geckodriver.exe");
		FirefoxDriver driver=new FirefoxDriver();
		driver.get("https://demo.dealsdray.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("prexo.mis@dealsdray.com");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("prexo.mis@dealsdray.com");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		WebDriverWait wait=new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='chevron_right']")));
		driver.findElement(By.xpath("//span[text()='chevron_right']")).click();
		driver.findElement(By.xpath("//span[text()='Orders']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Add Bulk Orders']")));
		driver.findElement(By.xpath("//button[text()='Add Bulk Orders']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='file']")));
		driver.findElement(By.xpath("//input[@type='file']")).sendKeys("C:\\Users\\Sanju Gowda\\Downloads\\demo-data.xlsx");
		driver.findElement(By.xpath("//button[text()='Import']")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Validate Data']")));
		driver.findElement(By.xpath("//button[text()='Validate Data']")).click();
		wait.until(ExpectedConditions.alertIsPresent());
		Alert a=driver.switchTo().alert();
		a.accept();
		Thread.sleep(3000);
		TakesScreenshot ts=(TakesScreenshot)driver;
		File s = ts.getScreenshotAs(OutputType.FILE);
		File d = new File("C:\\Users\\Sanju Gowda\\OneDrive\\Desktop\\Test\\Functionaltest\\output.jpeg");
		FileHandler.copy(s, d);
		driver.quit();
	}
}
