package UItest;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class Mobile
{
	public static void main(String[] args) throws InterruptedException, IOException 
	{
		int i=1;
		String[] browsers = { "chrome", "firefox" };
		Dimension[] dimension = { new Dimension(360, 640), new Dimension(414, 896), new Dimension(375, 667) };
		String[] URL = { "https://www.getcalley.com", "https://www.getcalley.com/calley-lifetime-offer/",
				"https://www.getcalley.com/see-a-demo/", "https://www.getcalley.com/calley-teams-features/",
				"https://www.getcalley.com/calley-pro-features/" };
		for (String B : browsers) 
		{
			WebDriver driver = drivers(B);
			if (driver != null) 
			{
				for (String url : URL) { 
					driver.get(url);
						for (Dimension D : dimension) 
						{
							driver.manage().window().setSize(D);
							TakesScreenshot ts = (TakesScreenshot) driver;
							File s = ts.getScreenshotAs(OutputType.FILE);
							File d = new File("C:\\Users\\Sanju Gowda\\OneDrive\\Desktop\\Test\\Mobile\\"+i+"_"+B+"_"+D+".jpeg");
							FileHandler.copy(s, d);
							i++;
						}
						Thread.sleep(4000);
					}
				}
			driver.quit();
			}
		}

	public static WebDriver drivers(String browsers) {
		WebDriver driver = null;
		switch (browsers.toLowerCase()) {
		case "chrome":
			System.setProperty("webdriver.chrome.driver", "./software/chromedriver.exe");
			driver = new ChromeDriver();
			break;
		case "firefox":
			System.setProperty("webdriver.gecko.driver", "./software/geckodriver.exe");
			driver = new FirefoxDriver();
			break;
		default:
			System.out.println("Invalid");
		}
		return driver;
	}
}
